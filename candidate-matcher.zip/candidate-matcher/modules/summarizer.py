# modules/summarizer.py
import os
import torch
from functools import lru_cache
from transformers import AutoTokenizer, AutoModelForCausalLM

# ----------------------------
# Configuration (via env vars)
# ----------------------------
MODEL_NAME = os.getenv("SUMMARIZER_MODEL", "google/gemma-2b-it")
USE_4BIT = os.getenv("USE_4BIT", "0") == "1"
USE_8BIT = os.getenv("USE_8BIT", "0") == "1"
ALLOW_FALLBACK = os.getenv("ALLOW_SUMMARY_FALLBACK", "0") == "1"  # opt-in only

def _format_prompt(role: str, jd: str, resume_text: str) -> str:
    """
    Tight, recruiter-style prompt to reduce generic fluff.
    """
    return (
        "You are an expert technical recruiter. "
        "Write a 2–3 sentence, specific summary explaining why the candidate is a good or poor fit. "
        "Reference concrete skills, frameworks, cloud/tools, years of experience, and any gaps. Avoid generic praise.\n\n"
        f"ROLE: {role}\n"
        f"JOB DESCRIPTION:\n{jd}\n\n"
        f"RESUME (raw text, may be noisy):\n{resume_text[:4000]}\n\n"
        "Return only the summary."
    )

@lru_cache(maxsize=1)
def _load_gemma():
    """
    Robust loader:
      - If CUDA is available:
          * FP16 on GPU by default
          * Optional 4-bit/8-bit quant via bitsandbytes
      - If CPU-only:
          * force plain CPU load (no device_map='auto', no offload)
    """
    tok = AutoTokenizer.from_pretrained(MODEL_NAME)

    if torch.cuda.is_available():
        quant_args = {}
        if USE_4BIT or USE_8BIT:
            try:
                from transformers import BitsAndBytesConfig
                if USE_4BIT:
                    quant_args["quantization_config"] = BitsAndBytesConfig(
                        load_in_4bit=True,
                        bnb_4bit_compute_dtype=torch.float16,
                    )
                elif USE_8BIT:
                    quant_args["quantization_config"] = BitsAndBytesConfig(load_in_8bit=True)
            except Exception as e:
                raise RuntimeError(
                    f"Quantized load requested (USE_4BIT/USE_8BIT) but bitsandbytes is unavailable: {e}\n"
                    "Fix: pip install bitsandbytes  (or unset USE_4BIT/USE_8BIT)"
                )

        model = AutoModelForCausalLM.from_pretrained(
            MODEL_NAME,
            device_map="auto",         # place weights on GPU automatically
            torch_dtype=torch.float16, # fp16 on GPU
            low_cpu_mem_usage=True,
            **quant_args,
        )
        try:
            dev = next(model.parameters()).device
            print(f"[Gemma] Loaded on: {dev}; 4bit={USE_4BIT} 8bit={USE_8BIT}")
        except Exception:
            pass
        return tok, model

    # CPU-only path (avoid accelerate offload)
    model = AutoModelForCausalLM.from_pretrained(
        MODEL_NAME,
        device_map=None,            # IMPORTANT: no 'auto' on CPU
        torch_dtype=torch.float32,  # fp32 CPU
        low_cpu_mem_usage=True,
    )
    model = model.to("cpu")
    print("[Gemma] Loaded on CPU")
    return tok, model

def _maybe_explain_auth_error(exc: Exception) -> RuntimeError:
    msg = str(exc)
    if "gated repo" in msg.lower() or "401" in msg or "access to model" in msg.lower():
        return RuntimeError(
            "Gemma is gated on Hugging Face and requires authentication.\n"
            "1) Request access at https://huggingface.co/google/gemma-2b-it\n"
            "2) Login locally:  pip install -U huggingface_hub  &&  huggingface-cli login\n"
            "Then restart your app."
        )
    if "offload" in msg.lower() and "disk_offload" in msg.lower():
        return RuntimeError(
            "Accelerate attempted to offload the whole model to disk.\n"
            "Fixes:\n"
            "- GPU available? Set USE_4BIT=1 (or USE_8BIT=1) and install bitsandbytes.\n"
            "- CPU-only? Use this file's CPU path (already configured) and ensure you didn't force device_map='auto' elsewhere."
        )
    return RuntimeError(f"Gemma load failed: {exc}")

@lru_cache(maxsize=1)
def _load_model_pair():
    """
    Load Gemma; optionally allow a fallback to FLAN-T5 if ALLOW_SUMMARY_FALLBACK=1.
    """
    try:
        return (*_load_gemma(), "gemma")
    except Exception as e:
        if not ALLOW_FALLBACK:
            raise _maybe_explain_auth_error(e)
        # Optional fallback (only if explicitly enabled)
        from transformers import AutoModelForSeq2SeqLM
        fb = "google/flan-t5-base"
        tok = AutoTokenizer.from_pretrained(fb)
        model = AutoModelForSeq2SeqLM.from_pretrained(
            fb,
            torch_dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        )
        if torch.cuda.is_available():
            model = model.cuda()
        print("[Summarizer] Falling back to FLAN-T5 (ALLOW_SUMMARY_FALLBACK=1)")
        return tok, model, "t5"

def generate_summary(role: str, jd: str, resume_text: str) -> str:
    tok, model, kind = _load_model_pair()
    prompt = _format_prompt(role, jd, resume_text)

    # Tokenize
    inputs = tok(prompt, return_tensors="pt", truncation=True, max_length=4096)
    if torch.cuda.is_available():
        inputs = {k: v.cuda() for k, v in inputs.items()}
        try:
            model = model.cuda()
        except Exception:
            pass

    if kind == "gemma":
        # Decoder-only generation (temperature matters only with sampling)
        out = model.generate(
            **inputs,
            max_new_tokens=160,
            do_sample=True,
            temperature=0.6,
            top_p=0.9,
            repetition_penalty=1.1,
            pad_token_id=getattr(tok, "eos_token_id", None),
        )
        text = tok.decode(out[0], skip_special_tokens=True).strip()
        # In case the model echoes the prompt, keep the tail after 'Return only the summary.'
        return text

    # Fallback: T5 (only if ALLOW_SUMMARY_FALLBACK=1)
    out = model.generate(
        **inputs,
        max_new_tokens=160,
        num_beams=4,                 # beam search works well for T5
        length_penalty=1.0,
        no_repeat_ngram_size=3,
        early_stopping=True,
    )
    return tok.decode(out[0], skip_special_tokens=True).strip()
