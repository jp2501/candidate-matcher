import streamlit as st
from components.sidebar import render_top_nav
from pages.dashboard import render as render_dashboard
from pages.settings import render as render_settings
from pages.results import render as render_results
from backend.main import run_create_match_ui

st.set_page_config(page_title="Candidate Matcher", page_icon="🧠", layout="wide")

# --- App-wide state defaults ---
if "page" not in st.session_state:
    st.session_state.page = "Create Match"
if "results" not in st.session_state:
    st.session_state.results = []
if "settings" not in st.session_state:
    st.session_state.settings = {
        "show_top_k": 10,
        "enable_ai_summary": True,
        "similarity_threshold": 0.0,
    }

# --- Navbar ---
selected = render_top_nav(default="Create Match")
st.session_state.page = selected

# --- Router ---
if st.session_state.page == "Dashboard":
    render_dashboard()
elif st.session_state.page == "Create Match":
    run_create_match_ui()
elif st.session_state.page == "Results":
    render_results()
elif st.session_state.page == "Settings":
    render_settings()
else:
    st.warning("Page not found.")
