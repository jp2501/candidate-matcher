import io
import csv
import streamlit as st
from modules.utils import to_table_rows

def render():
    st.title("Results")
    results = st.session_state.get("results", [])

    if not results:
        st.info("No results yet. Run a match from **Create Match**.")
        return

    st.caption("Showing results filtered by your Settings.")
    df = to_table_rows(results)
    st.dataframe(df, use_container_width=True)

    # Download CSV
    csv_bytes = io.StringIO()
    writer = csv.writer(csv_bytes)
    writer.writerow(["Name", "Score", "Summary"])
    for r in results:
        writer.writerow([r["name"], r["score"], r.get("summary", "")])
    st.download_button(
        "Download CSV",
        data=csv_bytes.getvalue().encode("utf-8"),
        file_name="candidate_match_results.csv",
        mime="text/csv",
    )
