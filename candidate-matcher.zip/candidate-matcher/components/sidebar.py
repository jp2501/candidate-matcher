import streamlit as st
from streamlit_option_menu import option_menu

def render_top_nav(default="Create Match"):
    with st.container():
        selected = option_menu(
            menu_title=None,
            options=["Dashboard", "Create Match", "Results", "Settings"],
            icons=["speedometer2", "plus-circle", "list-check", "gear"],
            orientation="horizontal",
            default_index=["Dashboard","Create Match","Results","Settings"].index(default),
            styles={
                "nav-link": {"padding": "8px 16px", "border-radius": "8px"},
                "nav-link-selected": {"background-color": "#1f6feb"},
            },
        )
    st.markdown("---")
    return selected
